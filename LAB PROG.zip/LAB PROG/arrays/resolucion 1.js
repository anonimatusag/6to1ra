let nombres = ["Maria","Matias","Laura","Lore"]
for(let i=0 ; i<1 ; i++)
{
  document.write("se mostrara los nombres: "+nombres)
}

let pos=0
do
{
    document.write("mi nombre es " +nombre+pos[0])
    pos++
}while(pos<4)
  do
  {
    nombre = prompt("ingrese un nombre")
  }while(nombre != null && nombre !='')
    console.log(nombre)