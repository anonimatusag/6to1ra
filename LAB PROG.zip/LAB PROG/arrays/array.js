let nombres = ["Tomas","Enrique","Lionel","Luis"]

let edades = [17,17,18,18]

nombres.push("Lionel")

let cant= nombres.length

document.write("hay " +cant+ " alumnos  en lista <br>" )

document.write("Mi nombre es " +nombres[4]+ " y tengo " +edades[4])
