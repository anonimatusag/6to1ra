let nombres = [];
let nombre = prompt("Ingresa un nombre:");

while (nombre) {
    nombres.push(nombre);
    nombre = prompt("Ingresa un nombre:");
}

document.write("Lista de nombres ingresados");
document.write(nombres);

