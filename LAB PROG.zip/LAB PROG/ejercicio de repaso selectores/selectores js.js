let nombres = document.querySelectorAll(`input`)
let boton = document.querySelector(`button`)

boton.addEventListener(`click`, function(){
    selector()
})
function selector(){
    let random = Math.floor((Math.random()*4))
    alert(nombres[random].value)
    
}