let cancha = document.getElementById("cancha")

let x = document.getElementById(x)
//agregar un evento a cualquier elemento
x.addEventListener('click', function(){   n  
})

function reservar(){
    let precio_cancha = cancha.value
    let nombre_cancha = cancha.selectedOptions[0].label
     // punto 1  //punto 2
     let hora1 = document.getElementById('desde').value
     let hora2 = document.getElementById('hasta').value
    
     if(hora2>hora1)
     {
     alert("la hora que ingreso es valida")
     }
     else
     {
     alert("la hora que ingreso es invalida")
     }
     alert( cantidad_horas = (hora1-hora2)*(-1))

     //punto 3
     let precio = document.getElementById('cancha')
     alert(precio = precio_cancha*cantidad_horas)
     
     //punto 4
     let carga = document.getElementById('reservas')
     let nombre = document.getElementById('nombre').value
     
     carga.innerHTML = nombre + precio + cantidad_horas+  nombre_cancha
     
     //extra
     if(nombre == "nico" && nombre_cancha == "Basquet")
     {
        document.getElementById('cuerpo').className = "verde"
     }
     
     alert(precio_cancha+nombre_cancha)

     
}