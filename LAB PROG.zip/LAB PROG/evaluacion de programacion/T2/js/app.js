let servicio = document.getElementById("servicio")

function reservar(){
    let precio_cancha = servicio.value
    let nombre_cancha = servicio.selectedOptions[0].label

    alert(precio_cancha+nombre_cancha)
}