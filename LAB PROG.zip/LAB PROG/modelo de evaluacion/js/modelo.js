let suma = 0

function agregar(){
    //OBTIENE EL NOMBRE DEL PRODUCTO
    let nombre_producto = document.getElementById("producto").selectedOptions[0].label
    //OBTIENE SU VALOR 
    let precio_producto = document.getElementById("producto").value
    
    //punto 1 //punto 3 
    let cantidad = document.getElementById('cantidad').value

    suma = precio_producto*cantidad + suma
    let sub_total = document.getElementById("sub_total")
    sub_total.innerHTML = "Sub Total: " + suma

    //punto 2
    let medio_pago = document.getElementById("pago").selectedOptions[0].label

    switch(medio_pago){
        case "efectivo": 
        let descuento = suma * 0.10
        let precio_final = suma - descuento
        let total = document.getElementById("total")
        total.innerHTML = "Total: " + precio_final
    }

//punto 4
    let ticket = document.getElementById('ticket')

    ticket.innerHTML = ticket.innerHTML + "<p>"+nombre_producto+"  cant:"+cantidad+"  $"+precio_producto+" <input type='button' value='x' onclick='eliminar(`lavandina`)'></p>"
}

function eliminar(nombre){
        alert(nombre)
}