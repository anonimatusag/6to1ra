

function agregar(){
    //OBTIENE EL NOMBRE DEL PRODUCTO
    let nombre_producto = document.getElementById("producto").selectedOptions[0].label
    //OBTIENE SU VALOR 
    let precio_producto = document.getElementById("producto").value
}