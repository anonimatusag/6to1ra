let dni = prompt("ingrese su dni")
esUnNumero(dni, "DNI")
let cp = prompt("ingrese su codigo postal")
esUnNumero(cp, "CP")
// if (isNaN(numero))
// {
//     document.writeln("no es un numero")
// }

function esUnNumero(numero, texto)
{
    if(isNaN(numero))
    {
        document.writeln("el "+texto+" no es un numero <br>")
    }
}