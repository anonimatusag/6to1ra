function sumador(num1, num2)
{
    let resultado = num1 + num2
    return resultado
}

//let a = sumador(10,7)

document.writeln(sumador(10,7))

function resta(num1, num2)
{
    let resultado = num1 - num2 
    return resultado
}

document.writeln(resta(20,10))

function multiplicacion (num1, num2)
{
let resultado = num1 * num2
return resultado
}
document.writeln(multiplicacion(10, 5))

function division(num1,num2)
{
    let resultado= num1 / num2
    if(division == 0)
            {
               document.writeln("no es posible la division")
            }
            else
            {
                document.writeln("es posible la division")
            } 
    return resultado
}                 
document.writeln(division(15,5))
