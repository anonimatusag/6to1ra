let nombres = document.querySelectorAll('input')
let boton = document.querySelector('button')

boton.addEventListener('click', function(){
    selector()
})

nombres.forEach(function(elemento){
    elemento.addEventListener('blur', function(){
        if(elemento.value==""){
            elemento.style.border = "2px solid red"
        }else{
            elemento.style.border = "1px solid black"
        }
    })
})





function selector(){
    console.log(Math.floor(Math.random()*4))
    //alert(nombres[3].value)
}