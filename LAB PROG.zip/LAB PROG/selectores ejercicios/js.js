let cont = document.querySelector('div>p')

alert(cont.innerHTML)

x=0

let boton1 = document.querySelector('button:nth-of-type(1)') 

boton1.addEventListener('click', function(){
    incremento()
})

function incremento(){
    let suma = cont + 1
    cont.innerHTML = suma
}

