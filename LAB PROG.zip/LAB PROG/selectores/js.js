//programacion boton 2
let boton2 = document.getElementById("bt2") //agarrando por el id

boton2.addEventListener("click", function(){
    msj()
})

//programacion boton 3
let boton3 = document.querySelector('button:nth-of-type(2)')

boton3.addEventListener('click', function(){
    msj()
})

//programacion boton 4
let boton4 = document.querySelector('.bt4')

boton4.addEventListener('click', function(){
    msj()
})

function msj(){
    alert("milanesa de pollo")
}