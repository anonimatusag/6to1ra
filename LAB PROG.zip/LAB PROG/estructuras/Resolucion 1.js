var auto =
{
    marca:"Wolksvagen"
    modelo:"voyage"
    año: 2012 
    matricula:"mau 934"
    registro: [
        {
        dueño:"Agustin Ayvar"
        dni: 42344332
        pais:"Argentina"
        }
    ]
}
document.writeln(auto.marca)
document.writeln(auto.modelo)
document.writeln(auto.año)
document.writeln(auto.matricula)
document.writeln(auto.registro[0].dueño)
document.writeln(auto.registro[1].dni)
document.writeln(auto.registro[2].pais)